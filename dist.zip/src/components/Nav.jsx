import { TextAnimate } from "@/registry/magicui/text-animate"

import "./Nav.css"

const links = [
  { label: "work", href: "#work" },
  { label: "about", href: "#about" },
  { label: "services", href: "#services" },
]

export function Nav({ onNavigate }) {
  return (
    <nav className="nav">
      {links.map((link, i) => (
        <a
          key={link.label}
          className="nav-link"
          href={link.href}
          onClick={(event) => {
            if (!onNavigate) return
            event.preventDefault()
            onNavigate(link.href.slice(1))
          }}
        >
          <TextAnimate
            as="span"
            animation="blurIn"
            startOnView={false}
            delay={i * 0.08}
          >
            {link.label}
          </TextAnimate>
        </a>
      ))}
    </nav>
  )
}
