import { useId } from 'react'

import './SmokeTransition.css'

export function SmokeTransition({ direction = 1, progress = 0 }) {
  const uid = useId().replace(/[^a-zA-Z0-9_-]/g, '')
  const filterA = `smoke-a-${uid}`
  const filterB = `smoke-b-${uid}`

  const x = direction === 1 ? (1 - 2 * progress) * 100 : (2 * progress - 1) * 100
  const fade = Math.min(1, progress / 0.2, (1 - progress) / 0.2)

  return (
    <div className="smoke" style={{ opacity: fade }} aria-hidden="true">
      <div className="smoke-core" style={{ transform: `translate3d(${x}vw, 0, 0)` }} />
      <div
        className="smoke-cloud smoke-cloud-a"
        style={{ transform: `translate3d(${x}vw, 0, 0)` }}
      >
        <svg className="smoke-svg" preserveAspectRatio="none">
          <defs>
            <filter
              id={filterA}
              x="-10%"
              y="-10%"
              width="120%"
              height="120%"
              colorInterpolationFilters="sRGB"
            >
              <feTurbulence
                type="fractalNoise"
                baseFrequency="0.0045 0.0085"
                numOctaves="5"
                seed="7"
                stitchTiles="stitch"
              />
              <feColorMatrix
                type="matrix"
                values="0 0 0 0 0.82  0 0 0 0 0.84  0 0 0 0 0.88  1.4 1.4 1.4 0 -1.5"
              />
              <feGaussianBlur stdDeviation="5" />
            </filter>
          </defs>
          <rect width="100%" height="100%" filter={`url(#${filterA})`} />
        </svg>
      </div>
      <div
        className="smoke-cloud smoke-cloud-b"
        style={{ transform: `translate3d(${x * 1.18}vw, 0, 0)` }}
      >
        <svg className="smoke-svg" preserveAspectRatio="none">
          <defs>
            <filter
              id={filterB}
              x="-10%"
              y="-10%"
              width="120%"
              height="120%"
              colorInterpolationFilters="sRGB"
            >
              <feTurbulence
                type="fractalNoise"
                baseFrequency="0.011 0.016"
                numOctaves="4"
                seed="23"
                stitchTiles="stitch"
              />
              <feColorMatrix
                type="matrix"
                values="0 0 0 0 0.78  0 0 0 0 0.8  0 0 0 0 0.84  1.2 1.2 1.2 0 -1.35"
              />
              <feGaussianBlur stdDeviation="3" />
            </filter>
          </defs>
          <rect width="100%" height="100%" filter={`url(#${filterB})`} />
        </svg>
      </div>
    </div>
  )
}
